package com.example.citivan;

import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class ReportAlertThread implements Runnable{
	
	private MapActivity mapActivity;
	private SharedPreferences sharedPref;
	
	public ReportAlertThread(MapActivity mapActivity){
		this.mapActivity = mapActivity;
		sharedPref = this.mapActivity.getSharedPreferences("com.example.citivan.json",
				Context.MODE_PRIVATE);
	}

	@Override
	public void run() {
		try {
			JSONObject user = new JSONObject(sharedPref.getString("user", ""));
			String reporter_id = user.getString("_id");
			float lat = (float)mapActivity.vehicleLocation.getLatitude();
			float lon = (float)mapActivity.vehicleLocation.getLatitude();
			String type = mapActivity.alertType.toLowerCase();
			//post the alert
			IrisCouch ic = new IrisCouch();
			ic.postAlert(reporter_id, lat, lon, type);
        } catch(Exception e){
        	Log.d("error", "alert posting", e);
        }	
	}
}
