package com.example.citivan;

import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

public class ReportLocationThread implements Runnable{
	
	private MapActivity mapActivity;
	private SharedPreferences sharedPref;

	public ReportLocationThread(MapActivity mapActivity){
		this.mapActivity = mapActivity;
		sharedPref = this.mapActivity.getSharedPreferences("com.example.citivan.json",
				Context.MODE_PRIVATE);
	}

	@Override
	public void run() {
	    try {  //TODO another hack here
			while (!mapActivity.isActivityDestroyed){
				IrisCouch ic = new IrisCouch();
				JSONObject license = new JSONObject(sharedPref.getString("license", ""));
				String vehicle_id = license.getString("vehicle_id");
				float lat = (float)mapActivity.vehicleLocation.getLatitude();
				float lon = (float)mapActivity.vehicleLocation.getLatitude();
				ic.updateLocation(vehicle_id, lat, lon);
				Thread.sleep(1 * 60 * 1000);
			}
        } catch(Exception e){
        	e.printStackTrace();
        }
	}
}
