package com.example.citivan;

import org.json.JSONException;
import org.json.JSONObject;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.ActionBar;
import android.support.v4.app.Fragment;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;
import android.os.Build;

//FIXME Somewhere there is a connection that is not being closed
public class LoginActivity extends ActionBarActivity {
	
	private LoginUser loginUser;
	private ProgressDialog dialog;
	private boolean login_set;
    
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_login);
		SharedPreferences sharedPref = getSharedPreferences("com.example.citivan.serverAddress",
				Context.MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPref.edit();
		editor.putString("serverAddress", "http://18.239.7.180/citivan/exp.php");
		editor.commit();
		
		loginUser = new LoginUser();
		login_set = false;
		
		EditText editText = (EditText) findViewById(R.id.password);
		editText.setOnEditorActionListener(new OnEditorActionListener() {
		    @Override
		    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
		        boolean handled = false;
		        if (actionId == EditorInfo.IME_ACTION_DONE) {
		        	//this method call is a hack. Might need to be avoided
		            onSubmitBtnClick(null);
		            handled = true;
		        }
		        return handled;
		    }
		});	
	}
	
	public void onSubmitBtnClick(View view){
		EditText usernameEditText=(EditText) findViewById(R.id.username);
		EditText passwordEditText=(EditText) findViewById(R.id.password);
		String username = usernameEditText.getText().toString();
		String password = passwordEditText.getText().toString();
		String url = getSharedPreferences("com.example.citivan.serverAddress",
				Context.MODE_PRIVATE).getString("serverAddress", "none");
		
		if(loginUser.getStatus().equals(AsyncTask.Status.RUNNING)){
			Toast.makeText(getApplicationContext(), "Request already submitted", Toast.LENGTH_LONG).show();
		}
		
		else if (login_set){
			//If we are already logged in we don't want do it again, so we just ignore
			
		}
		
		else{
			loginUser = new LoginUser();
			loginUser.execute(new String[]{username, password});
			dialog = ProgressDialog.show(this, "", 
                    "Authenticating. Please wait...", true);
		}
	}
	
	/**
	 * This class extends the AsyncTask. It checks the server for the existense of the user.
	 *
	 */
	private class LoginUser extends AsyncTask<String, Void, JSONObject>{
		
		@Override
		protected JSONObject doInBackground(String... input) {
			String username = input[0];
			String password = input[1];
	        //log in the user
	        IrisCouch ic = new IrisCouch();
	        JSONObject login_status = ic.logIn(username, password);
	        return login_status;
		}
		
		@Override
		protected void onPostExecute(JSONObject status) {
			if (status != null){
				if (status.has("ok")){
					login_set = true;
					Intent intent = new Intent(getApplicationContext(), MapActivity.class);
					try {
						intent.putExtra("user_name", status.getString("name"));
						dialog.dismiss();
						startActivity(intent);
						finish();
					} catch (JSONException e) {
						alertUser("Server Error");
						e.printStackTrace();
					}
				} else {
					dialog.dismiss();
					alertUser("Access Denied");
				}
			} else {
				dialog.dismiss();
				alertUser("Connection failed");
			}
	     }
	}
	
	private void alertUser(String message) {
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
		//alertDialogBuilder.setTitle("Your Title");
		alertDialogBuilder.setMessage(message)
		                  .setCancelable(false)
		                  .setPositiveButton("Ok",new DialogInterface.OnClickListener() {
					         public void onClick(DialogInterface dialog,int id) {
						        dialog.cancel();
					         }
					       });
		AlertDialog alertDialog = alertDialogBuilder.create();
		alertDialog.show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.login, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
