package com.example.citivan;

import android.annotation.SuppressLint;
import android.util.Log;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * IrisCouch is an interface between the Iris Couch server and the application.
 * TODO IrisCouch doesn't seem very appropriate. The API is very bad the last time I worked on it. Deprecating this whole thing is the best 
 *
 */
@SuppressLint("NewApi")
public class IrisCouch {
	
	/**
	 * Execute an HTTP request and return the response body as a JSONObject 
	 * @param url - the full url of the request
	 * @param params - a list of parameters in the request
	 * @param method - the HTTP method to use. One of GET, POST and PUT
	 * @param body - the body of the request. It can be null.
	 * @return - the response body object. It is null when there has been an error.
	 */
	private JSONObject executeRequest(String url, List<NameValuePair> params, String method, String body){
		try {
			HttpClient httpClient = new DefaultHttpClient();
			HttpUriRequest requestMethod = null;
			if (method.equals("post")){
				HttpPost post = new HttpPost(url);
				if (params != null)
					post.setEntity(new UrlEncodedFormEntity(params));
				if (body != null){
					post.setEntity(new StringEntity(body));
				}
				requestMethod = (HttpUriRequest)post;
			}
			else if (method.equals("get")){
				requestMethod = new HttpGet(url);
			}
			else if (method.equals("put")){
				HttpPut put = new HttpPut(url);
				put.setEntity(new StringEntity(body));
				//TODO this is a hack.
				put.setHeader("Referer", "http://en.wikipedia.org/wiki/Main_Page");
				requestMethod = (HttpUriRequest) put;
			}
			
			//set headers
			requestMethod.setHeader("Accept", "application/json");
			if (body != null)
				requestMethod.setHeader("Content-Type", "application/json");
			
			//execute the request
			HttpResponse httpResponse = httpClient.execute(requestMethod);
			
			//process the response
            HttpEntity httpEntity = httpResponse.getEntity();
            
            InputStream is = httpEntity.getContent();
            BufferedReader reader = new BufferedReader(new InputStreamReader(
                    is, "iso-8859-1"), 8);
            StringBuilder sb = new StringBuilder();
            
            String line = null;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            
            //close the client
			//httpClient.getConnectionManager().shutdown();
            httpEntity.consumeContent();
            reader.close();
            is.close();
            //create and return the JSONObject
            String json = sb.toString();
            return new JSONObject(json);
            
		} catch (UnsupportedEncodingException e) {
		    //TODO
		} catch (ClientProtocolException e){
		    //Log.d("error2", "mina", e);
		} catch (IOException e){
		    //TODO
		} catch (JSONException e){
		    //TODO
		}
		return null;
	}
	
	/**
	 * Logs in the user.
	 * @param username (string) - Username of the user. Should not be empty.
	 * @param password (string) - Password of the user. Should not be empty.
	 * @return - JSONObject that has the authorization status of the user. It has the following format:
	 * {"roles":[],"name": String, "ok": Boolean}
	 */
	public JSONObject logIn(String username, String password){
	    //FIXME this url probably no longer work
		String url = "http://ambush.iriscouch.com/_session";
		List<NameValuePair> params = new ArrayList<NameValuePair>();
		params.add(new BasicNameValuePair("name", username));
		params.add(new BasicNameValuePair("password", password));
		JSONObject js = executeRequest(url, params, "post", null);
		return js;
	}
	
	/**
	 * Fetches for and returns the logged in user's information
	 * @return - JSONObject which has the format below:<br>
<pre>{
	_id: String, 
	license_id: String,
	name: String, 
	full_name: {
		first_name: String,
	 	surname: String,
	},
	_attachments:{
		firstname_surname.jpg:{
			data: String
		}
	}
}</pre>
	 */
	public JSONObject getUserData(String user_id) {
		String url = "http://ambush.iriscouch.com/_users/" + user_id + "?attachments=true";
		Log.d("url", url);
		JSONObject user_data = executeRequest(url, null, "get", null);
		return user_data;
	}
	
	/**
	 * Get the logged in users ratings
	 * @param license_id - the unique id of the license
	 * @return - JSONObject which has the format below
<pre>{
	_id: string,
	_rev: string,
	start_date: integer,
	end_date: integer,
	vehicle_id: string,
	route_id: string
}</pre>
	 */
	public JSONObject getUserLicense(String license_id) {
		JSONObject license = null;
		String url = "https://ambush.iriscouch.com:6984/licenses/" + license_id;
		license = executeRequest(url, null, "get", null);
		return license;
	}
	
	/**
	 * Fetches and computes the rating of the user
	 * @param vehicle_id - the id of the vehicle that the user drives
	 * @param start_date - the time stamp of the driver's license start date
	 * @param end_date - the time stamp of the driver's license end date. It can be -1 when the 
	 * end date is not defined
	 * @return - a JSONArray of the average ratings in each of the three categories, and the total
	 * number of ratings. It has the format: [safety, cleanliness, courtesy, num_ratings]
	 */
	public JSONArray getUserRatings(String vehicle_id, int start_date, int end_date){
		try {
			//when the license has no end date use the current date
			if (end_date == -1)
				end_date = (int) (System.currentTimeMillis() / 1000);
			//create the url
			String from = new JSONArray().put(vehicle_id).put(start_date).toString().
					replace("\"", "%22");
			String to = new JSONArray().put(vehicle_id).put(end_date).toString().
					replace("\"", "%22");
			String url = "https://ambush.iriscouch.com:6984/ratings/_design/user_ratings/_view/all_ratings?startkey="
					+ from + "&endkey=" + to;
			/*
			 * get the ratings data. Each rating has the format (excluding unnecessary data)
			 * {
					value: {
						_id: "442dd5c8eb03f41997652e7a62000133",
						vehicle_id: "1",
						cleanliness: 5,
						safety: 4,
						courtesy: 3,
						time: 1419826537
					}
				}
			 */
			
			JSONArray ratingsRawData = executeRequest(url, null, "get", null).getJSONArray("rows");
			float cleanliness, safety, courtesy;
			cleanliness = safety = courtesy = 0;
			int j = ratingsRawData.length();
			for (int i = 0; i < j; i++){
				JSONObject ratingsData = ratingsRawData.getJSONObject(i).getJSONObject("value");
				cleanliness += ratingsData.getInt("cleanliness");
				safety += ratingsData.getInt("safety");
				courtesy += ratingsData.getInt("courtesy");
			}
			//the list of average ratings and the total number of ratings
			JSONArray average_ratings = new JSONArray();
			average_ratings.put(safety/j).put(courtesy/j).put(cleanliness/j).put(j);
			return average_ratings;
		}  catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Get the route from the server that the driver is supposed to follow.
	 * @param route_id - the unique id of the route that the driver is supposed to follow
	 * @return - a list in the form of a JSONArray of latitude and longitude values representing the route
	 */
	public JSONArray getUserRoute(String route_id){
		try {
			String url = "http://ambush.iriscouch.com/routes/" + route_id;
			JSONArray route =  executeRequest(url, null, "get", null).getJSONArray("lat_lon");
			return route;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * Get the markers from the server that correspond to specified coordinates
	 * @param min_lat - the minimum latitude value that the marker should have
	 * @param max_lat - the maximum latitude value that the marker should have
	 * @param min_lon - the minimum longitude value that the marker should have
	 * @param max_lon - the maximum longitude value that the marker should have
	 * @return - a list of the markers in the form of a JSONArray. The object has the following format 
	 * (excluding unnecessary data):<br>
	 * 
<pre>[{
	"value":{
	   "_id": String,
	   "reporter_id": String,
	   "time": int,
	   "lat": float,
	   "lon": float,
	   "type": String. One of {accident, crime, hazard, sos}
	}
}...]</pre>
	 */
	public JSONArray getMarkers(double min_lat, double max_lat, double min_lon, double max_lon){
		try {
			//create the url
			String from = new JSONArray().put(min_lat).put(min_lon).toString();
			String to = new JSONArray().put(max_lat).put(max_lon).toString();
			String url = "https://ambush.iriscouch.com:6984/alerts/_design/alerts/_view/sorted_alerts?startkey="
					+ from + "&endkey=" + to;
			JSONArray markers = executeRequest(url, null, "get", null).getJSONArray("rows");
			return markers;
		} catch (JSONException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	/**
	 * Post an alert to the server.
	 * @param reporter_id - the unique id of the reporter
	 * @param lat - the current latitude of the driver
	 * @param lon - the current longitude of the driver
	 * @param type - type of the alert. One of {accident, crime, hazard, sos}
	 */
	public void postAlert(String reporter_id, float lat, float lon, String type){
		try {
			String url = "https://ambush.iriscouch.com:6984/alerts";
			JSONObject request = new JSONObject();
			request.put("reporter_id", reporter_id).put("lat", lat).put("lon", lon).put("type", type);
			executeRequest(url, null, "post", request.toString());
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Updates the location of the vehicle as recorded in the server
	 * @param rev - the revision number of the vehicle document on IrisCouch
	 * @param vehicle_id - the unique id of the vehicle
	 * @param lat - the current latitude of the vehicle
	 * @param lon - the current longitude of the vehicle
	 */
	public void updateLocation(String vehicle_id, float lat, float lon){
		try {
	
			String url = "https://ambush.iriscouch.com:6984/vehicles/" + vehicle_id;
			//get vehicle document from the server
			JSONObject vehicle = executeRequest(url, null, "get", null);
			//create and execute request
			JSONObject request = new JSONObject();
			JSONObject location = new JSONObject().put("lat", lat).put("lon", lon)
					.put("last_updated", System.currentTimeMillis() / 1000);
			request.put("location", location);
			request.put("_rev", vehicle.getString("_rev"));
			executeRequest(url, null, "put", request.toString());
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String... args){
		IrisCouch ic = new IrisCouch();
		//login the user
		JSONObject login_status = ic.logIn("", "");
		if (login_status.has("ok")){
			//get user data
			String user_id = "org.couchdb.user:";
			JSONObject user_data = ic.getUserData(user_id);
			try {
				JSONObject license = ic.getUserLicense(user_data.getString("license_id"));
				int start_date = license.getInt("start_date");
				int end_date = license.getInt("end_date");
				//get the user ratings
				String vehicle_id = license.getString("vehicle_id");
				//float[] ratings = ic.getUserRatings(vehicle_id, start_date, end_date);
				//get the user route
				String route_id = license.getString("route_id");
				JSONArray route = ic.getUserRoute(route_id);
				//get the markers
				JSONArray markers = ic.getMarkers(42, 43, -72, -71);
				//post alert
				//String user_id = user_data.getString("_id");
				//ic.postAlert(user_id, 1, 0, "crime");
				//update location
				//ic.updateLocation(vehicle_id, 2, 2);
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		else{
			//we are screwed
		}
	}
}
