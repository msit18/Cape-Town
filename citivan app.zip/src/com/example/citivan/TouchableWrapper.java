package com.example.citivan;

import android.content.Context;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.widget.FrameLayout;

public class TouchableWrapper extends FrameLayout{
	private long lastTouchedAt;
	private static final long SCROLL_TIME = 200L;
	private UpdateMapAfterUserAction updateMapAfterUserAction;
	
	public TouchableWrapper(Context context) {
		super(context);
		try{
			updateMapAfterUserAction = (MapActivity) context;
		} catch (ClassCastException e){
			throw new ClassCastException(context.toString() + " must implement UpdateMapAfterUserAction");
		}
	}
	
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN:
			lastTouchedAt = SystemClock.uptimeMillis();
			break;
		case MotionEvent.ACTION_UP:
			final long now = SystemClock.uptimeMillis();
			if (now - lastTouchedAt > SCROLL_TIME) {
				updateMapAfterUserAction.onUpdateMapAfterUserAction();
			}
			break;
		}
		return super.dispatchTouchEvent(ev);
	}
	
	public interface UpdateMapAfterUserAction{
		public void onUpdateMapAfterUserAction();
	}
	
}