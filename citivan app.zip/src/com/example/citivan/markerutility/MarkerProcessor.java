package com.example.citivan.markerutility;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.example.citivan.IrisCouch;
import com.example.citivan.MapActivity;
import com.example.citivan.AppServerCommunication;
import com.google.android.gms.maps.model.LatLng;
import com.google.common.collect.ImmutableMap;
import com.google.maps.android.MarkerManager.Collection;
import android.annotation.SuppressLint;
import android.os.AsyncTask;
import android.util.Log;

public class MarkerProcessor extends AsyncTask<Double, Void, List<Alert>>{
	public MapActivity mapActivity;
	public MarkerProcessor(MapActivity mapActivity){
		this.mapActivity = mapActivity;
	}
	
	@Override
	protected List<Alert> doInBackground(Double... input) {
		Double[] lats = new Double[4];
		Double[] lons = new Double[4];
		System.arraycopy(input, 0, lats, 0, 4);
		System.arraycopy(input, 4, lons, 0, 4);
        IrisCouch ic = new IrisCouch();
        double min_lat = Collections.min(Arrays.asList(lats));
        double max_lat = Collections.max(Arrays.asList(lats));
        double min_lon = Collections.min(Arrays.asList(lons));
        double max_lon = Collections.max(Arrays.asList(lons));
		try {
			//get markers from the server
	        JSONArray markers = ic.getMarkers(min_lat, max_lat, min_lon, max_lon);
	        //make alerts
	        List<Alert> newAlerts = new ArrayList<Alert>();
	        
			for (int i = 0; i < markers.length(); i++){
				JSONObject marker = markers.getJSONObject(i).getJSONObject("value");
				String markerType = marker.getString("type");
				LatLng latLng = new LatLng(marker.getDouble("lat"), marker.getDouble("lon"));
				newAlerts.add(new Alert(latLng, markerType, mapActivity.alertDrawables.get(markerType)));
			}
			return newAlerts;
		} catch (JSONException e) {
			e.printStackTrace();
		} catch (NullPointerException e){
			
		}
        return null;
	}
	
	@Override
	protected void onPostExecute(List<Alert> result) {
		if (result != null){
			mapActivity.mClusterManager.clearItems();
			mapActivity.mClusterManager.addItems(result);
			mapActivity.mClusterManager.cluster();
		}
	}

}
