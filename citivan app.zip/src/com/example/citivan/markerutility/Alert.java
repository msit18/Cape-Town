package com.example.citivan.markerutility;

import com.google.android.gms.maps.model.LatLng;
import com.google.maps.android.clustering.ClusterItem;

public class Alert implements ClusterItem{
	private final LatLng position;
	public final String type;
	public final int alertImage;
	public Alert(LatLng position, String type, int drawable){
		this.position = position;
		this.type = type;
		this.alertImage = drawable;
	}

	@Override
	public LatLng getPosition() {
		return position;
	}

}
