package com.example.citivan.markerutility;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.view.Display;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.citivan.MapActivity;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.maps.android.clustering.Cluster;
import com.google.maps.android.clustering.view.DefaultClusterRenderer;
import com.google.maps.android.ui.IconGenerator;

public class AlertRenderer extends DefaultClusterRenderer<Alert> implements GoogleMap.OnCameraChangeListener{
	private final IconGenerator mIconGenerator;
	private final ImageView mImageView;
	private MapActivity mapActivity;
	public AlertRenderer(MapActivity mapActivity) {
		super(mapActivity.getApplicationContext(), mapActivity.googleMap, mapActivity.mClusterManager);
		this.mapActivity = mapActivity;
		mImageView = new ImageView(mapActivity.getApplicationContext());
        int dpi = mapActivity.getResources().getDisplayMetrics().densityDpi;
        int dp = 30;//we want dp by dp images
        mIconGenerator = new IconGenerator(mapActivity.getApplicationContext());
		mImageView.setLayoutParams(new ViewGroup.LayoutParams(dp * dpi/ 160, dp * dpi/ 160));
		mIconGenerator.setContentView(mImageView);
	}
	
	@Override
	protected void onBeforeClusterItemRendered(Alert alert, MarkerOptions markerOptions){
		mImageView.setImageResource(alert.alertImage);
		Bitmap icon = mIconGenerator.makeIcon();
        markerOptions.icon(BitmapDescriptorFactory.fromBitmap(icon));
	}
	
	@Override
    protected boolean shouldRenderAsCluster(Cluster cluster) {
        // Always render clusters.
        return cluster.getSize() > 1;
    }

	@Override
	public void onCameraChange(CameraPosition arg) {
		//This makes sure that we do not access markers until we have location data
		//Initial zoom level is high which can add pressure on the server when accessing many markers
		if (mapActivity.vehicleLocation == null){
			return;
		}
		
		Display display = mapActivity.getWindowManager().getDefaultDisplay();
		int width = display.getWidth();
		int height = display.getHeight();
		LatLng topLeft = mapActivity.googleMap.getProjection().fromScreenLocation(new Point(0, 0));
		LatLng topRight = mapActivity.googleMap.getProjection().fromScreenLocation(new Point(width, 0));
		LatLng bottomLeft = mapActivity.googleMap.getProjection().fromScreenLocation(new Point(0, height));
		LatLng bottomRight = mapActivity.googleMap.getProjection().fromScreenLocation(new Point(width, height));
		MarkerProcessor markerProcessor = new MarkerProcessor(mapActivity);
		Double[] input = new Double[]{
				topLeft.latitude,
				topRight.latitude,
				bottomLeft.latitude,
				bottomRight.latitude,
				topLeft.longitude,
				topRight.longitude,
				bottomLeft.longitude,
				bottomRight.longitude};
		markerProcessor.execute(input);
	}
}
