package com.example.citivan;

import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.example.citivan.TouchableWrapper.UpdateMapAfterUserAction;
import com.example.citivan.markerutility.Alert;
import com.example.citivan.markerutility.AlertRenderer;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GooglePlayServicesUtil;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.UiSettings;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.common.collect.ImmutableMap;
import com.google.common.io.BaseEncoding;
import com.google.maps.android.clustering.ClusterManager;

import android.support.v7.app.ActionBarActivity;
import android.support.v4.app.ActionBarDrawerToggle;
import android.support.v4.widget.DrawerLayout;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RatingBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MapActivity extends ActionBarActivity implements LocationListener, SensorEventListener, UpdateMapAfterUserAction {
	public GoogleMap googleMap;
    public Location vehicleLocation;
    private String[] alertNames;
	private DrawerLayout alertDrawerLayout;
	private ListView alertDrawerList;
	private ActionBarDrawerToggle mDrawerToggle;
	private SensorManager mSensorManager;
	private Sensor accelerometer;
	private Sensor magnetometer;
	private float[] mGravity;
	private float[] mGeomagnetic;
	private float bearing = (float) 0.0;
	private UiSettings mUiSettings;
	private LocationManager locationManager;
	private LinearLayout drawerLinearLayout;
	public boolean isActivityDestroyed = false;//true if current activity has been destroyed
	public String alertType;
	private boolean mapDragged = false;//true if map has been dragged
	public Map<String,Integer> alertDrawables;//a map of alert types and alert images
	public ClusterManager<Alert> mClusterManager;
	private JSONObject user;
	
	@SuppressLint("NewApi")
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_map);
		//setup the UI
		setupDrawer();
		setupMap();
        refineUserProfileViewDimensions();
        
        //set up the sensors
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
	    magnetometer = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
	    accelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
	    
	    //run the location reporting thread
	    ReportLocationThread connection = new ReportLocationThread(this);
		Thread t = new Thread(connection);
		//TODO start the thread 
		//t.start();
		
		//map alert names to corresponding drawables
		alertDrawables = ImmutableMap.of("accident", R.drawable.accident, 
				"roadwork", R.drawable.hazard,
				"crime", R.drawable.crime,
				"sos", R.drawable.sos);
		
		//populate the UI with user info etc.
		new UIPopulationTask().execute(new Void[]{});
	}
	
	/**
	 * The implementation puts the following on the UI: user's full name, user's photo, user's
	 * ratings, the route. This data is also stored in a SharedPreference for later use.
	 *
	 */
	@SuppressLint("NewApi")
	private class UIPopulationTask extends AsyncTask<Void, Void, Void>{

		@Override
		protected Void doInBackground(Void... params) {
	        try {
	        	Intent intent = getIntent();
		        String user_name = intent.getStringExtra("user_name");
		        IrisCouch ic = new IrisCouch();
		        
		        //get the data
		        user = ic.getUserData("org.couchdb.user:" + user_name);
	        	String license_id = user.getString("license_id");
	        	JSONObject license = ic.getUserLicense(license_id);
	        	JSONArray ratings = ic.getUserRatings(license.getString("vehicle_id"), license.getInt("start_date"),
	        			license.getInt("end_date"));
	        	JSONArray route = ic.getUserRoute(license.getString("route_id"));
	        	
	        	//store the data
	        	SharedPreferences sharedPref = getSharedPreferences("com.example.citivan.json",
	    				Context.MODE_PRIVATE);
	    		SharedPreferences.Editor editor = sharedPref.edit();
	    		editor.putString("user", user.toString()).putString("license", license.toString())
	    			.putString("ratings", ratings.toString()).putString("route", route.toString());
	    		editor.commit();
	    		
	    		//now that we have the license information stored, we can start the location thread
	    		//TODO find somewhere that makes sense to put the code below.
	    		ReportLocationThread connection = new ReportLocationThread(MapActivity.this);
	    		Thread t = new Thread(connection);
	    		t.start();
	        } catch (JSONException e) {
				e.printStackTrace();
			}
	        return null;
		}
		
		@Override
		protected void onPostExecute(Void result){
			//TODO create a single sharedPref object
			SharedPreferences sharedPref = getSharedPreferences("com.example.citivan.json",
    				Context.MODE_PRIVATE);
			try {
				//put user info on the UI
				JSONObject user = new JSONObject(sharedPref.getString("user", ""));
				JSONObject full_name = user.getJSONObject("full_name");
				String firstname = full_name.getString("first_name");
				String surname = full_name.getString("surname");
				//FIXME change "accident.jpg" to username + ".jpg"
				String base64image = user.getJSONObject("_attachments").getJSONObject("accident.jpg")
						.getString("data");
				byte[] imageByteArray = BaseEncoding.base64().decode(base64image);
				Bitmap bitmap = BitmapFactory.decodeByteArray(imageByteArray , 0, imageByteArray .length);
				putUserPersonalInfo(firstname + " " + surname, bitmap);
				
				//put ratings
				JSONArray ratings = new JSONArray(sharedPref.getString("ratings", ""));
				putUserRatings(ratings);
				
				//put route
				JSONArray route = new JSONArray(sharedPref.getString("route", ""));
				putRoute(route);
				
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * This method ensures that the photo and the score view are the right size with respect 
	 * to the rest of the screen. The score view should be circular
	 */
	private void refineUserProfileViewDimensions() {
		Display display = getWindowManager().getDefaultDisplay();
        int width = display.getWidth();  // deprecated
        LinearLayout userImageAndScoreLinearLayout = (LinearLayout) findViewById(R.id.imageAndScore);
        LayoutParams lp = userImageAndScoreLinearLayout.getLayoutParams();
        lp.height = width/4;
        lp.width = width/2;
        
        View toplevelContainer = findViewById(R.id.midlevel_container);
        RelativeLayout.LayoutParams lptlc = 
        		(RelativeLayout.LayoutParams)toplevelContainer.getLayoutParams();
        lptlc.addRule(RelativeLayout.ALIGN_PARENT_RIGHT, R.id.midlevel_container);
        userImageAndScoreLinearLayout.setLayoutParams(lp);
	}
	
	public void onLayoutClick(View view){
		int view_id = view.getId();
		LinearLayout profileExtraLayout = (LinearLayout) findViewById(R.id.profileExtra);
		switch(view_id){
		case R.id.imageAndScore:
			if(profileExtraLayout.getVisibility()==View.INVISIBLE){
				profileExtraLayout.setVisibility(View.VISIBLE);
			}
			else{
				profileExtraLayout.setVisibility(View.INVISIBLE);
			}
			break;
			
		case R.id.profileExtra:
			profileExtraLayout.setVisibility(View.INVISIBLE);
			break;
		}
	}
    
	public void putUserPersonalInfo(String name, Bitmap bitmap){
		TextView userName = (TextView) findViewById(R.id.userName);
		ImageView userImageView = (ImageView) findViewById(R.id.imageView1);
		userImageView.setImageBitmap(bitmap);
		userName.setText(name);
	}
	
	public void putUserRatings(JSONArray ratings) throws JSONException {
		TextView ratingsCount = (TextView)findViewById(R.id.userRatings);
		if ((int)ratings.get(3) != 1){
			ratingsCount.setText((int)ratings.getInt(3) + " Ratings");
		}
		else{
			ratingsCount.setText("1 Rating");
		}
		
		RatingBar safetyBar = (RatingBar) findViewById(R.id.safeDrivingRatingBar);
		safetyBar.setRating((float) ratings.getDouble(0));

		RatingBar courtesyBar = (RatingBar) findViewById(R.id.courtesyRatingBar);
		courtesyBar.setRating((float) ratings.getDouble(1));
		
		RatingBar cleanlinessBar = (RatingBar) findViewById(R.id.cleanlinessRatingBar);
		cleanlinessBar.setRating((float) ratings.getDouble(2));
	}
	
	public void putRoute(JSONArray route){
		PolylineOptions options = new PolylineOptions();
		try {
			for (int i = 0; i < route.length(); i++){
				
					JSONArray point = route.getJSONArray(i);
				    LatLng a = new LatLng(point.getDouble(0), point.getDouble(1));
				    options.add(a).color(Color.BLUE);	
			}
			googleMap.addPolyline(options);
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
	
	//////////SENSOR CALL BACKS
	@Override
	public void onAccuracyChanged(Sensor arg0, int arg1) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onSensorChanged(SensorEvent event) {
		float alpha = 0.125f;
		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER){
			if (mGravity == null){
				mGravity = event.values.clone();
			}
			else{
				mGravity[0] = event.values[0] * alpha + (1 - alpha) * mGravity[0]; 
			    mGravity[1] = event.values[1] * alpha + (1 - alpha) * mGravity[1];
			    mGravity[2] = event.values[2] * alpha + (1 - alpha) * mGravity[2];
			} 
		}
		if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD){
			if (mGeomagnetic == null){
				mGeomagnetic = event.values.clone();
			}
			else{
				mGeomagnetic[0] = event.values[0] * alpha + (1 - alpha) * mGeomagnetic[0]; 
				mGeomagnetic[1] = event.values[1] * alpha + (1 - alpha) * mGeomagnetic[1];
				mGeomagnetic[2] = event.values[2] * alpha + (1 - alpha) * mGeomagnetic[2]; 
			}
		}
		
		if (mGravity != null && mGeomagnetic != null) {
			float R[] = new float[9];
		    float I[] = new float[9];
		    boolean success = SensorManager.getRotationMatrix(R, I, mGravity,mGeomagnetic);
	
			if (success) {
				float orientation[] = new float[3];
				SensorManager.getOrientation(R, orientation);
				float azimuth = orientation[0];
				bearing = (float)((azimuth)* 180/Math.PI);
			}
		}
	}
	
	//////////MAPS
	/*
	 * This method puts the map on the screen. The map is moved to the current position
	 */
	public void setupMap(){
		int status = GooglePlayServicesUtil.isGooglePlayServicesAvailable(getBaseContext());
        if(status!=ConnectionResult.SUCCESS){ // Google Play Services are not available
        	int requestCode = 10;
            Dialog dialog = GooglePlayServicesUtil.getErrorDialog(status, this, requestCode);
            dialog.show();
        }
        else {
			SupportMapFragment fm = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
			googleMap = fm.getMap();
			googleMap.setMyLocationEnabled(true);
			mUiSettings = googleMap.getUiSettings();
			mUiSettings.setZoomControlsEnabled(false);
			mUiSettings.setCompassEnabled(false);
			
	        locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
	        Criteria criteria = new Criteria();
	        String provider = locationManager.getBestProvider(criteria, true);
	        Location location = locationManager.getLastKnownLocation(provider);
	        vehicleLocation = location;
	        
	        if(location!=null){
	            onLocationChanged(location);//this is a hack
	        }
	        
	        locationManager.requestLocationUpdates(provider, 1000 * 60 * 1, 0,  this);
	        
	        mClusterManager = new ClusterManager<Alert>(this, googleMap);
	        mClusterManager.setRenderer(new AlertRenderer(this));
	        googleMap.setOnCameraChangeListener(mClusterManager);
        }
	}
	
	@Override
	public void onUpdateMapAfterUserAction() {
		mapDragged = true;
	}
	
	@Override
	public void onLocationChanged(Location location) {
		vehicleLocation = location;
		moveToCurrentPosition();
	}
	
	public void onMyLocationButtonClick(View view){
		mapDragged = false;
		moveToCurrentPosition();
	}
	
	public void onSearchRouteButtonClick(View view){
		if (vehicleLocation == null){
			Toast.makeText(getApplicationContext(), "Location data not available", 
					  Toast.LENGTH_LONG).show();
			return;
		}
		Uri locationUri = Uri.parse("http://maps.google.com/maps?q="+ 
								vehicleLocation.getLatitude() +"," + 
								vehicleLocation.getLongitude());
		Intent mapIntent = new Intent(Intent.ACTION_VIEW ,locationUri );

		// Verify it resolves
		PackageManager packageManager = getPackageManager();
		List<ResolveInfo> activities = packageManager.queryIntentActivities(mapIntent, 0);
		boolean isIntentSafe = activities.size() > 0;

		if (isIntentSafe) {
		    startActivity(mapIntent);
		}
	}
	
	/*
	 * This centers the map on the current position. It is called when there is a change of position 
	 */
	public void moveToCurrentPosition(){
		if (vehicleLocation == null){
			Toast.makeText(getApplicationContext(), "Location data not available", 
					  Toast.LENGTH_LONG).show();
			return;
		}
		if (mapDragged){
			return;
		}
		
		double latitude = vehicleLocation.getLatitude();
		double longitude = vehicleLocation.getLongitude();		
		LatLng latLng = new LatLng(latitude, longitude);
		
		CameraPosition currentPosition =
	            new CameraPosition.Builder().target(latLng)
	                    .zoom(15)
	                    .bearing(bearing)
	                    .build();
		googleMap.moveCamera(CameraUpdateFactory.newCameraPosition(currentPosition));
	}
	
	@Override
	public void onProviderDisabled(String provider) {
	}
    
	@Override
	public void onProviderEnabled(String provider) {
	}

	@Override
	public void onStatusChanged(String provider, int status, Bundle extras) {
	}

	//////////DRAWER
	public void setupDrawer(){
		alertNames = getResources().getStringArray(R.array.alerts_array);
        alertDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);
        alertDrawerList = (ListView) findViewById(R.id.left_drawer);
        drawerLinearLayout = (LinearLayout) findViewById(R.id.left_drawer2);
        alertDrawerList.setAdapter(new ArrayAdapter<String>(this,
                R.layout.alert_item, alertNames));
        alertDrawerList.setOnItemClickListener(new DrawerItemClickListener());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        
        mDrawerToggle = new ActionBarDrawerToggle(
                this,                  /* host Activity */
                alertDrawerLayout,         /* DrawerLayout object */
                R.drawable.ic_drawer,  /* nav drawer image to replace 'Up' caret */
                R.string.drawer_open,  /* "open drawer" description for accessibility */
                R.string.drawer_close  /* "close drawer" description for accessibility */
                ) {
        	
			@Override
			public void onDrawerClosed(View view) {
            }

			@Override
			public void onDrawerOpened(View drawerView) {
            }
            
            @Override
    		public void onDrawerSlide(View arg0, float arg1) {
    			//alertDrawerList.bringToFront();
            	drawerLinearLayout.bringToFront();
    	        alertDrawerLayout.requestLayout();
    	        alertDrawerLayout.invalidate();
    			
    		}

    		@Override
    		public void onDrawerStateChanged(int arg0) {
    			//alertDrawerList.bringToFront();
    			drawerLinearLayout.bringToFront();
    	        alertDrawerLayout.requestLayout();
    	        alertDrawerLayout.invalidate();
    			
    		}
        };
        
        alertDrawerLayout.setDrawerListener(mDrawerToggle);
	}
	
	/* The click listener for ListView in the navigation drawer */
    private class DrawerItemClickListener implements ListView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            selectItem(position);
        }
    }
    
    private void selectItem(int position) {
        // update selected item and title, then close the drawer
        alertDrawerList.setItemChecked(position, true);
        setTitle(alertNames[position]);
        alertDrawerLayout.closeDrawer(drawerLinearLayout);
        alertType = alertNames[position];
        getConfirmation();
    }
    
    private void getConfirmation() {
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
		Drawable icon = getResources().getDrawable(alertDrawables.get(alertType.toLowerCase()));
		alertDialogBuilder.setTitle("Confirm").setIcon(alertDrawables.get(alertType.toLowerCase()));
		alertDialogBuilder.setMessage("Do you want to send " + alertType.toUpperCase() + " report?")
		                  .setCancelable(true)
		                  .setPositiveButton("Yes",new DialogInterface.OnClickListener() {
		                	  public void onClick(DialogInterface dialog,int id) {
		                		  
		                		  if(vehicleLocation == null){
		                			  Toast.makeText(getApplicationContext(), "Location data not available", 
                					  Toast.LENGTH_LONG).show();
		                		  } 
		                		  else{
		                			  Toast.makeText(getApplicationContext(), 
		                					  "Thanks for sending " + alertType.toUpperCase() + " alert", 
		                					  Toast.LENGTH_LONG).show();
		                			  ReportAlertThread alertsThread = new ReportAlertThread(MapActivity.this);
		                			  new Thread(alertsThread).start();
		                		  }
		                	  }
					       	})
					       .setNegativeButton("No", new DialogInterface.OnClickListener() {
							   @Override
								public void onClick(DialogInterface dialog, int which) {
								   //
								}
						});
		
		AlertDialog alertDialog = alertDialogBuilder.create();
		alertDialog.show();
	}
    
    public void onLogoutClick(View view){
    	finish();
    }
    
    public void onDummyViewClick(View view){
    	//when we click on empty space on the drawer, we close it. 
    	alertDrawerLayout.closeDrawer(drawerLinearLayout);
    }
	////////////////ACTIVITY//////////////////////////
    @Override
	protected void onResume() {
    	super.onResume();
	    mSensorManager.registerListener(this, magnetometer , SensorManager.SENSOR_DELAY_NORMAL);
	    mSensorManager.registerListener(this, accelerometer , SensorManager.SENSOR_DELAY_NORMAL);
	}

	@Override
	protected void onPause() {
	    super.onPause();
	    mSensorManager.unregisterListener(this);
	}
	 
	@Override
	protected void onDestroy(){
		super.onDestroy();
		this.isActivityDestroyed = true;
	}
	
    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        // Sync the toggle state after onRestoreInstanceState has occurred.
        mDrawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        mDrawerToggle.onConfigurationChanged(newConfig);
    }

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.map, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		// Pass the event to ActionBarDrawerToggle, if it returns
        // true, then it has handled the app icon touch event
        if (mDrawerToggle.onOptionsItemSelected(item)) {
          return true;
        }
		return super.onOptionsItemSelected(item);
	}
	
}
